import React from 'react'

export const MainContext = () => {
    return (
        <div>MainContext</div>
    )
}

export const CONFIG = {
    uri: 'https://financy-app-grawa9dta2cmbkhd.eastus-01.azurewebsites.net'
    //uri: 'http://localhost:4000'
}
export const firebaseConfig = {
    apiKey: "AIzaSyDUFH6TDtO_2wMl3Xn7rJf890TKApi6FD4",
    authDomain: "commy-f812a.firebaseapp.com",
    projectId: "commy-f812a",
    storageBucket: "commy-f812a.appspot.com",
    messagingSenderId: "288405510760",
    appId: "1:288405510760:web:499533a58315c8edce39dd",
    measurementId: "G-QR9VYFVK3J"
};
